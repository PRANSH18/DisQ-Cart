// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyCb2Jeivd594NEMyEqqcx5aJe6l7WpJE_I",
    authDomain: "disq-cart-51523.firebaseapp.com",
    projectId: "disq-cart-51523",
    storageBucket: "disq-cart-51523.appspot.com",
    messagingSenderId: "333760943116",
    appId: "1:333760943116:web:60edd52444931f5dbe8a29",
    measurementId: "G-J8N12XJZE1"
  };